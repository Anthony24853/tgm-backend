from flask import Flask, request, jsonify
import openai
import os

app = Flask(__name__)

openai.api_key = os.getenv("OPENAI_API_KEY") or "sk-REPLACE_WITH_YOUR_KEY"

@app.route('/analyze', methods=['POST'])
def analyze_signal():
    data = request.get_json()
    candles = data.get("candles", [])
    symbol = data.get("symbol", "XAUUSD")
    timeframe = data.get("timeframe", "M15")

    prompt = build_prompt(candles, symbol, timeframe)

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a forex trading analyst."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )
        reply = response['choices'][0]['message']['content']
        return jsonify(parse_reply(reply))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def build_prompt(candles, symbol, timeframe):
    return f"""
Analyze the following {symbol} candle data on {timeframe}:
{candles}

Rules:
- Only return a signal if it is an A+ setup.
- Focus on 200+ pip TP, with no more than 10 pip SL.
- Consider EMA, RSI conditions, and market structure.
- Only send one of these signals: buy, sell, or none.

Respond in JSON format like this:
{{
  "signal": "buy",
  "entry": 2330.00,
  "sl": 2320.00,
  "tp": 2370.00,
  "confidence": 0.91
}}
    """.strip()

def parse_reply(reply_text):
    import json
    try:
        return json.loads(reply_text)
    except:
        return {"error": "Invalid JSON from OpenAI", "raw": reply_text}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)))